# الدليل الشامل والعملي: تشغيل AirPointer في Android Studio وتثبيته على هاتفك ورفعه على Google Play

**المشروع:** AirPointer (مؤشر سطح المكتب بالهواء)  
**المطور:** MOUNAIM IA  
**الهوية البصرية:** Kinetic Obsidian (النمط الليلي السيان المعتمد)

---

## الخطوة 1: نقل المشروع والملفات إلى Android Studio

### 1.1 إنشاء المشروع الجديد:
1. افتح برنامج **Android Studio** (نسخة Hedgehog أو Iguana أو Jellyfish أو أحدث).
2. اختر **New Project** ثم حدد قالب **Empty Views Activity** (وليس Empty Compose).
3. عبّئ البيانات كالتالي:
   - **Name:** `AirPointer`
   - **Package name:** `ai.mounaim.airpointer`
   - **Language:** `Kotlin`
   - **Minimum SDK:** `API 26: Android 8.0 (Oreo)` (يدعم 95% من أجهزة أندرويد الحديثة ومناسب لخدمات الكاميرا والـ Overlay).
   - **Build configuration language:** `Kotlin DSL (build.gradle.kts)` أو `Groovy (build.gradle)`.

---

### 1.2 إضافة المكتبات المطلوبة في `app/build.gradle`:
افتح ملف `app/build.gradle` وأضف المكتبات التالية داخل كتلة `dependencies { ... }`:

```groovy
dependencies {
    // 1. مكتبات أندرويد الأساسية وواجهات Jetpack
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.activity:activity-ktx:1.8.2'
    implementation 'androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0'
    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.7.0'

    // 2. محرك الذكاء الاصطناعي وتتبع اليد MediaPipe
    implementation 'com.google.mediapipe:tasks-vision:0.10.14'

    // 3. مكتبة الكاميرا CameraX لمعالجة إطارات السبابة السريعة
    def camerax_version = "1.3.2"
    implementation "androidx.camera:camera-core:${camerax_version}"
    implementation "androidx.camera:camera-camera2:${camerax_version}"
    implementation "androidx.camera:camera-lifecycle:${camerax_version}"

    // 4. خدمات Google Play والمزامنة السحابية مع Google Drive
    implementation 'com.google.android.gms:play-services-auth:21.0.0'
    implementation 'com.google.api-client:google-api-client-android:2.2.0'
    implementation 'com.google.apis:google-api-services-drive:v3-rev20230822-2.0.0'
    implementation 'com.google.code.gson:gson:2.10.1'

    // 5. Coroutines للعمليات الخلفية
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
}
```
*قم بتفعيل ViewBinding بإضافة التالي داخل بلوك `android { ... }`:*
```groovy
buildFeatures {
    viewBinding true
}
```
ثم اضغط على زر **Sync Now** في أعلى البرنامج.

---

### 1.3 نسخ ولصق الملفات البرمجية الجاهزة:
قم بنقل الملفات التي تم إعدادها في لوحة العمل إلى مساراتها المقابلة:
- **`AndroidManifest.xml`** ➔ انقله إلى `app/src/main/AndroidManifest.xml` (يحتوي على أذونات `SYSTEM_ALERT_WINDOW`, `CAMERA`, `BIND_ACCESSIBILITY_SERVICE`).
- **`accessibility_service_config.xml`** ➔ انقله إلى `app/src/main/res/xml/accessibility_service_config.xml`.
- **ملفات Kotlin:**
  - `MainActivity.kt` ➔ `app/src/main/java/ai/mounaim/airpointer/ui/`
  - `SettingsViewModel.kt` ➔ `app/src/main/java/ai/mounaim/airpointer/ui/viewmodel/`
  - `DriveSyncManager.kt` ➔ `app/src/main/java/ai/mounaim/airpointer/sync/`
  - `AirGestureEngine.kt` ➔ `app/src/main/java/ai/mounaim/airpointer/tracking/`
  - `WindowDragController.kt` ➔ `app/src/main/java/ai/mounaim/airpointer/overlay/`
  - `AirPointerAccessibilityService.kt` ➔ `app/src/main/java/ai/mounaim/airpointer/service/`
  - `AirPointerOverlayService.kt` ➔ `app/src/main/java/ai/mounaim/airpointer/service/`
- **ملفات الواجهات والرسم (Layout & Drawables):**
  - `activity_main.xml` ➔ `app/src/main/res/layout/`
  - `layout_air_pointer_cursor.xml` ➔ `app/src/main/res/layout/`
  - ملفات الـ Drawables المتجهة (`ic_air_pointer_arrow_classic.xml`, `bg_cursor_click_ripple.xml`, إلخ) ➔ `app/src/main/res/drawable/`.
  - الأيقونة الرسمية المعتمدة (`MOUNAIM IA`) ➔ ضعها كأيقونة تطبيق عبر: النقر بالزر الأيمن على مجلد `res` ➔ **New** ➔ **Image Asset** ➔ واختيار الصورة.

---

## الخطوة 2: تثبيت التطبيق وتشغيله فوراً على هاتفك الشخصي (Direct Install)

### 2.1 تفعيل وضع المطور وتصحيح USB في هاتفك:
1. افتح **إعدادات الهاتف (Settings)** ➔ **حول الهاتف (About Phone)**.
2. اضغط على **رقم الإصدار (Build Number)** 7 مرات متتالية حتى تظهر رسالة: *"أنت الآن مطور برامج!"*.
3. ارجع للإعدادات ➔ **خيارات المطور (Developer Options)** ➔ فعّل خيار **تصحيح أخطاء USB (USB Debugging)**.

### 2.2 توصيل الهاتف بالكمبيوتر والتثبيت:
1. وصّل الهاتف بالكمبيوتر عبر كابل USB أصلي.
2. ستظهر نافذة منبثقة على شاشة الهاتف: *"هل تريد السماح بتصحيح أخطاء USB؟"* ➔ اختر **السماح دائماً (Always allow)** ثم **موافق**.
3. في شريط الأدوات العلوي ببرنامج **Android Studio**، ستلاحظ ظهور اسم وموديل هاتفك في قائمة الأجهزة (Devices list).
4. اضغط على زر التشغيل الأخضر **Run 'app' (Shift + F10)** أو السهم الأخضر ▶️.
5. سيقوم Android Studio ببناء ملف الـ APK وتثبيته مباشرة على هاتفك وفتحه تلقائياً.

### 2.3 تفعيل الأذونات على الهاتف بعد أول تشغيل:
1. عند فتح تطبيق **AirPointer** لأول مرة، اضغط على تفعيل **الظهور فوق التطبيقات** وامنحه الصلاحية.
2. سيتم توجيهك لشاشة **إمكانية الوصول (Accessibility)** ➔ اختر **AirPointer** وقم بتفعيله (هذا ضروري لمحاكاة النقر الحقيقي).
3. امنح إذن **الكاميرا**، وضع يدك أمام الكاميرا الأمامية على مسافة 5 إلى 10 سم ليظهر سهم الماوس فوراً ويتحرك مع حركة سبابتك في الهواء!

---

## الخطوة 3: تجهيز التطبيق والرفع على متجر Google Play

### 3.1 إنشاء حزمة الإنتاج الموقعة (Generate Signed Android App Bundle - AAB):
تتطلب Google حزم بصيغة `.aab` بدلاً من `.apk` العادي:
1. في القائمة العلوية لـ Android Studio: اضغط على **Build** ➔ **Generate Signed Bundle / APK...**.
2. اختر **Android App Bundle** ثم اضغط **Next**.
3. بجانب **Key store path**، اضغط على **Create new...** لإنشاء مفتاح التوقيع الرقمي:
   - اختر مسار حفظ المفتاح (احفظه في مكان آمن جداً ولا تحذفه أبداً).
   - أدخل كلمة مرور قوية (Password).
   - اكتب اسم المطور: `MOUNAIM IA`، وأكمل الحقول المطلوبة.
4. اضغط **Next**، ثم حدد نوع البناء **release**، وفعّل علامتي التحقق.
5. اضغط **Finish**؛ سينشئ Android Studio ملفاً باسم `app-release.aab` في مجلد `app/release/`.

---

### 3.2 خطوات الرفع في حساب Google Play Console:
1. ادخل إلى [Google Play Console](https://play.google.com/console) وسجّل الدخول بحساب المطور الخاص بك.
2. اضغط على **إنشاء تطبيق (Create App)**:
   - **App name:** `AirPointer: مؤشر سطح المكتب بالهواء`
   - **Default language:** العربية (ar).
   - **App or Game:** App.
   - **Free or Paid:** Free (مجاني).
3. **إكمال بطاقة بيانات المتجر الرئيسية (Store Listing):**
   - **الوصف القصير (Short description):**  
     `تحكم بسهم ماوس سطح المكتب على شاشة هاتفك بإيماءات السبابة في الهواء دون لمس الشاشة.`
   - **الوصف الكامل (Full description):**  
     انسخ النص الترويجي المعتمد من صفحة المتجر المصممة في لوحة العمل.
   - **أيقونة التطبيق (App Icon):** ارفع صورة الأيقونة ثلاثية الأبعاد المعتمدة بدقة `512x512 px`.
   - **الرسم المميز (Feature Graphic):** ارفع صورة ترويجية بدقة `1024x500 px`.
   - **لقطات الشاشة (Screenshots):** ارفع لقطات الشاشات الست التي صممناها في المشروع.
4. **سياسة الخصوصية وأمان البيانات (Data Safety):**
   - أجب عن استبيان الخصوصية بأن معالجة الكاميرا تتم **محلياً فقط على الجهاز (On-Device Processing)** لتتبع السبابة ولا يتم تسجيل أي فيديو أو نقل صور عبر الإنترنت.
   - خدمة Accessibility تستخدم حصرياً لمحاكاة نقرات المؤشر بناءً على طلب المستخدم.
5. **رفع حزمة التطبيق (Upload Bundle):**
   - انتقل إلى **الإنتاج (Production)** أو **الاختبار الداخلي (Internal Testing)**.
   - اضغط **إنشاء إصدار جديد (Create new release)** وارفع ملف `app-release.aab`.
   - اكتب ملاحظات الإصدار (Release Notes):  
     `الإصدار الأولي 1.0.0: تحكم كامل بمؤشر سطح المكتب بالهواء، معالجة فورية للسبابة، ومزامنة سحابية مع Google Drive.`
6. اضغط على **مراجعة الإصدار (Review release)** ثم **بدء الإطلاق (Start rollout)** لإرساله لمراجعة فريق Google Play ونشره رسمياً!
