# كود واجهات وملفات سهم الماوس العائم لمشروع أندرويد ستوديو (layout_air_pointer_cursor.xml)
**المشروع:** AirPointer (مؤشر سطح المكتب بالهواء)  
**المطور:** MOUNAIM IA  
**الهدف:** تصميم وبرمجة ملف واجهة الـ XML لسهم الماوس العائم (`layout_air_pointer_cursor.xml`) الذي ترسمه خدمة `AirPointerOverlayService` فوق كافة التطبيقات والألعاب، مع ملفات الـ Vector Drawables للأشكال والأنماط وتأثيرات نبض ورادار النقر الهوائي.

---

## 1. ملف واجهة المؤشر العائم الأساسي: `layout_air_pointer_cursor.xml`
قم بإنشاء هذا الملف في المسار:  
`app/src/main/res/layout/layout_air_pointer_cursor.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/cursorRootLayout"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:clipChildren="false"
    android:clipToPadding="false">

    <!-- 1. هالة النبض ورادار النقر الهوائي (Air Click Ripple Effect) -->
    <ImageView
        android:id="@+id/imgClickRipple"
        android:layout_width="64dp"
        android:layout_height="64dp"
        android:layout_gravity="top|start"
        android:layout_marginStart="-12dp"
        android:layout_marginTop="-12dp"
        android:alpha="0"
        android:src="@drawable/bg_cursor_click_ripple"
        tools:alpha="0.8" />

    <!-- 2. تأثير التوهج النيوني المحيط بالسهم (Neon Glow Aura) -->
    <ImageView
        android:id="@+id/imgCursorGlow"
        android:layout_width="44dp"
        android:layout_height="44dp"
        android:layout_gravity="top|start"
        android:layout_marginStart="-2dp"
        android:layout_marginTop="-2dp"
        android:alpha="0.6"
        android:src="@drawable/ic_cursor_glow_cyan" />

    <!-- 3. أيقونة سهم الماوس الفعلي (Vector Arrow / Cursor Asset) -->
    <ImageView
        android:id="@+id/imgCursorPointer"
        android:layout_width="36dp"
        android:layout_height="36dp"
        android:layout_gravity="top|start"
        android:adjustViewBounds="true"
        android:elevation="12dp"
        android:src="@drawable/ic_air_pointer_arrow_classic"
        android:contentDescription="@string/air_pointer_cursor_desc" />

    <!-- 4. مؤشر الحالة والمسافة المصغّر (ارتفاع اليد والـ Radar Distance) -->
    <LinearLayout
        android:id="@+id/layoutDistanceBadge"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="bottom|end"
        android:layout_marginStart="24dp"
        android:layout_marginTop="24dp"
        android:background="@drawable/bg_cursor_distance_tag"
        android:gravity="center_vertical"
        android:orientation="horizontal"
        android:paddingStart="6dp"
        android:paddingTop="2dp"
        android:paddingEnd="6dp"
        android:paddingBottom="2dp"
        android:visibility="visible">

        <!-- نقطة استشعار حالة الكاميرا المضيئة -->
        <View
            android:id="@+id/viewTrackingDot"
            android:layout_width="6dp"
            android:layout_height="6dp"
            android:layout_marginEnd="4dp"
            android:background="@drawable/bg_tracking_status_active" />

        <TextView
            android:id="@+id/tvAirDistance"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:fontFamily="sans-serif-medium"
            android:textColor="#00F0FF"
            android:textSize="9sp"
            android:textStyle="bold"
            tools:text="7.2 cm" />
    </LinearLayout>

</FrameLayout>
```

---

## 2. ملفات الرسم والمتجهات (Drawables) لسهم المؤشر والهالات

### أ. ملف سهم الماوس الكلاسيكي الفخم: `ic_air_pointer_arrow_classic.xml`
قم بإنشائه في: `app/src/main/res/drawable/ic_air_pointer_arrow_classic.xml`

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="36dp"
    android:height="36dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <!-- الظل الخارجي للسهم -->
    <path
        android:fillColor="#80000000"
        android:pathData="M4,4 L11,22 L14,15 L21,12 Z" />
    <!-- جسم سهم الماوس الرئيسي مع حدود بلون النيون والمحيط المظلم -->
    <path
        android:fillColor="#00F0FF"
        android:strokeColor="#0A0E16"
        android:strokeWidth="1.6"
        android:strokeLineJoin="round"
        android:strokeLineCap="round"
        android:pathData="M3,3 L10,21 L13,14 L20,11 Z" />
    <!-- لمسة إضاءة داخلية عاكسة ثلاثية الأبعاد -->
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M4.5,5 L9,17 L10.8,12.8 L15,11 Z" />
</vector>
```

---

### ب. ملف هالة التوهج النيوني: `ic_cursor_glow_cyan.xml`
قم بإنشائه في: `app/src/main/res/drawable/ic_cursor_glow_cyan.xml`

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:aapt="http://schemas.android.com/aapt"
    android:width="44dp"
    android:height="44dp"
    android:viewportWidth="44"
    android:viewportHeight="44">
    <path android:pathData="M22,22m-20,0a20,20 0,1 1,40 0a20,20 0,1 1,-40 0">
        <aapt:attr name="android:fillColor">
            <gradient
                android:centerX="22"
                android:centerY="22"
                android:gradientRadius="20"
                android:type="radial">
                <item android:color="#5500F0FF" android:offset="0.0" />
                <item android:color="#2000F0FF" android:offset="0.6" />
                <item android:color="#00000000" android:offset="1.0" />
            </gradient>
        </aapt:attr>
    </path>
</vector>
```

---

### ج. ملف نبض النقر بالهواء (Ripple Wave): `bg_cursor_click_ripple.xml`
قم بإنشائه في: `app/src/main/res/drawable/bg_cursor_click_ripple.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <stroke
        android:width="2.5dp"
        android:color="#00F0FF" />
    <solid android:color="#2600F0FF" />
</shape>
```

---

### د. خلفية بطاقة المسافة والـ Radar Badge: `bg_cursor_distance_tag.xml`
قم بإنشائه في: `app/src/main/res/drawable/bg_cursor_distance_tag.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <corners android:radius="12dp" />
    <solid android:color="#D90F131C" />
    <stroke
        android:width="1dp"
        android:color="#4000F0FF" />
</shape>
```

---

### هـ. مؤشر التتبع الفعّال (Active Sensor Dot): `bg_tracking_status_active.xml`
قم بإنشائه في: `app/src/main/res/drawable/bg_tracking_status_active.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#10B981" />
</shape>
```

---

## 3. كود تفاعل وأنيميشن النقر في خدمة النافذة العائمة (`AirPointerOverlayService.kt`)

قم بتحديث كود خدمة `AirPointerOverlayService` في أندرويد لربط عناصر الـ XML والتفاعل الحركي الفوري عند النقر بالهواء:

```kotlin
package ai.mounaim.airpointer.service

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import ai.mounaim.airpointer.R

class AirPointerOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var cursorView: View
    private lateinit var layoutParams: WindowManager.LayoutParams

    private lateinit var imgCursorPointer: ImageView
    private lateinit var imgClickRipple: ImageView
    private lateinit var tvAirDistance: TextView

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 300
            y = 500
        }

        // نفخ وتثبيت واجهة سهم الماوس layout_air_pointer_cursor
        cursorView = LayoutInflater.from(this).inflate(R.layout.layout_air_pointer_cursor, null)
        imgCursorPointer = cursorView.findViewById(R.id.imgCursorPointer)
        imgClickRipple = cursorView.findViewById(R.id.imgClickRipple)
        tvAirDistance = cursorView.findViewById(R.id.tvAirDistance)

        windowManager.addView(cursorView, layoutParams)
    }

    /**
     * تحديث موضع المؤشر ومسافة السبابة فورياً من مستشعر الكاميرا
     */
    fun updateCursor(newX: Int, newY: Int, distanceCm: Float) {
        layoutParams.x = newX
        layoutParams.y = newY
        windowManager.updateViewLayout(cursorView, layoutParams)

        tvAirDistance.text = String.format("%.1f cm", distanceCm)
    }

    /**
     * تنفيذ أنيميشن النقر في الهواء (Air Click Animation & Ripple)
     */
    fun triggerAirClickAnimation() {
        // 1. ضغط خفيف لسهم المؤشر (Press Feedback)
        val scaleDownX = ObjectAnimator.ofFloat(imgCursorPointer, "scaleX", 1f, 0.85f, 1f).setDuration(120)
        val scaleDownY = ObjectAnimator.ofFloat(imgCursorPointer, "scaleY", 1f, 0.85f, 1f).setDuration(120)

        // 2. إطلاق موجة الرادار المضيئة (Click Ripple)
        val rippleScaleX = ObjectAnimator.ofFloat(imgClickRipple, "scaleX", 0.5f, 1.8f).setDuration(260)
        val rippleScaleY = ObjectAnimator.ofFloat(imgClickRipple, "scaleY", 0.5f, 1.8f).setDuration(260)
        val rippleAlpha = ObjectAnimator.ofFloat(imgClickRipple, "alpha", 0.9f, 0f).setDuration(260)

        AnimatorSet().apply {
            playTogether(scaleDownX, scaleDownY, rippleScaleX, rippleScaleY, rippleAlpha)
            start()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::cursorView.isInitialized) {
            windowManager.removeView(cursorView)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
```

---

## 4. نصوص الموارد المطلوبة في `strings.xml`
قم بإضافتها في: `app/src/main/res/values/strings.xml`

```xml
<resources>
    <string name="air_pointer_cursor_desc">سهم ماوس مؤشر الهواء العائم - مطور بواسطة MOUNAIM IA</string>
</resources>
```
