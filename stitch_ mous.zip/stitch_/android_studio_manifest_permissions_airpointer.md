# إعدادات Android Studio البرمجية لمشروع AirPointer
**المشروع:** AirPointer (مؤشر سطح المكتب بالهواء)  
**المطور:** MOUNAIM IA  
**الهدف:** ضبط ملف `AndroidManifest.xml` وتكوين أذونات الظهور فوق التطبيقات (`SYSTEM_ALERT_WINDOW`)، خدمة إمكانية الوصول للنقر والسكرول (`AccessibilityService`)، مستشعرات الكاميرا وتتبع السبابة، ومزامنة Google Drive.

---

## 1. ملف `AndroidManifest.xml` الكامل

قم بوضع هذا الكود في مسار: `app/src/main/AndroidManifest.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="ai.mounaim.airpointer">

    <!-- ======================================================== -->
    <!-- الأذونات الأساسية (Hardware & System Permissions)        -->
    <!-- ======================================================== -->

    <!-- إذن الكاميرا ومستشعرات الرؤية لتتبع حركة السبابة -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature
        android:name="android.hardware.camera"
        android:required="true" />
    <uses-feature
        android:name="android.hardware.camera.autofocus"
        android:required="false" />
    <uses-feature
        android:name="android.hardware.camera.front"
        android:required="true" />

    <!-- إذن الظهور والطفو فوق كافة التطبيقات والألعاب (رسم سهم الماوس) -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <!-- إذن ردود الفعل اللمسية والاهتزاز عند النقر في الهواء -->
    <uses-permission android:name="android.permission.VIBRATE" />

    <!-- أذونات الاتصال والإنترنت لمزامنة تفضيلات الإعدادات مع Google Drive -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- إذن إبقاء المعالجة نشطة أثناء التتبع في الخلفية -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" />

    <!-- تحسين استهلاك الطاقة ومنع إيقاف التتبع في الخلفية -->
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AirPointer"
        tools:targetApi="34">

        <!-- النشاط الرئيسي للتطبيق (Dashboard) -->
        <activity
            android:name=".ui.MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:theme="@style/Theme.AirPointer">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- خدمة النافذة العائمة لرسم مؤشر سطح المكتب (Overlay Service) -->
        <service
            android:name=".service.AirPointerOverlayService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="camera" />

        <!-- خدمة إمكانية الوصول لتنفيذ النقر الحقيقي والتمرير (Accessibility Service) -->
        <service
            android:name=".service.AirPointerAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

    </application>

</manifest>
```

---

## 2. ملف تهيئة خدمة إمكانية الوصول (`accessibility_service_config.xml`)

قم بإنشاء هذا الملف في المسار: `app/src/main/res/xml/accessibility_service_config.xml`  
هذا الملف يُخبر نظام أندرويد بأن الخدمة مسؤولة عن إرسال إيماءات النقر (`dispatchGesture`) بدون لمس الشاشة:

```xml
<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:description="@string/accessibility_service_description"
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagPerformGestures"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="100"
    android:canPerformGestures="true"
    android:canRetrieveWindowContent="true" />
```

---

## 3. كود طلب أذونات الظهور والوصول تلقائياً (`PermissionManager.kt`)

ضع هذا الكود في الكلاس البرمجي للتحقق من أذونات الظهور فوق الشاشة وطلبها بطريقة سلسة:

```kotlin
package ai.mounaim.airpointer.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity

object PermissionManager {

    // 1. التحقق من صلاحية الظهور فوق التطبيقات (Overlay)
    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    // طلب صلاحية الظهور فوق التطبيقات ونقل المستخدم للشاشة المخصصة
    fun requestOverlayPermission(activity: AppCompatActivity, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${activity.packageName}")
            )
            activity.startActivityForResult(intent, requestCode)
        }
    }

    // 2. التحقق من تفعيل خدمة إمكانية الوصول (Accessibility)
    fun isAccessibilityServiceEnabled(context: Context, serviceClass: Class<*>): Boolean {
        val expectedComponentName = "${context.packageName}/${serviceClass.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        return enabledServices.split(':').any {
            it.equals(expectedComponentName, ignoreCase = true)
        }
    }

    // فتح صفحة إعدادات إمكانية الوصول لتفعيل المؤشر
    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
```

---

## 4. كود النافذة العائمة لسهم الماوس (`AirPointerOverlayService.kt`)

هذا الكود هو المسؤول عن إضافة مؤشر الماوس العائم على شاشة أندرويد عبر الـ `WindowManager`:

```kotlin
package ai.mounaim.airpointer.service

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import ai.mounaim.airpointer.R

class AirPointerOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var pointerView: View
    private lateinit var layoutParams: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // تحديد نوع الطبقة للظهور فوق التطبيقات الأخرى
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 200
            y = 400
        }

        // إنشاء وتثبيت سهم المؤشر
        pointerView = LayoutInflater.from(this).inflate(R.layout.layout_air_pointer_cursor, null)
        windowManager.addView(pointerView, layoutParams)
    }

    // تحديث موقع المؤشر فورياً وفق حركة السبابة
    fun updateCursorPosition(newX: Int, newY: Int) {
        layoutParams.x = newX
        layoutParams.y = newY
        windowManager.updateViewLayout(pointerView, layoutParams)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::pointerView.isInitialized) {
            windowManager.removeView(pointerView)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
```

---

## 5. مقتطف ملف `build.gradle` (مكتبات MediaPipe والكاميرا وGoogle Drive)

```groovy
dependencies {
    // 1. معالجة وتتبع حركة اليد والسبابة بالذكاء الاصطناعي
    implementation 'com.google.mediapipe:tasks-vision:0.10.14'

    // 2. الكاميرا CameraX للرصد السريع في الخلفية
    implementation 'androidx.camera:camera-core:1.3.2'
    implementation 'androidx.camera:camera-camera2:1.3.2'
    implementation 'androidx.camera:camera-lifecycle:1.3.2'

    // 3. الربط السحابي مع Google Drive API
    implementation 'com.google.android.gms:play-services-auth:21.0.0'
    implementation 'com.google.api-client:google-api-client-android:2.2.0'
    implementation 'com.google.apis:google-api-services-drive:v3-rev20230822-2.0.0'
}
```
